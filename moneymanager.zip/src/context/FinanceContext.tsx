import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { addDays, addWeeks, addMonths, addYears, isBefore, parseISO, format } from 'date-fns';

export type AccountType = 'BANK' | 'CREDIT_CARD' | 'LOAN_PAYABLE' | 'LOAN_RECEIVABLE' | 'WALLET';

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  balance: number;
  bankName?: string;
  accountNumber?: string;
  color: string;
}

export type TransactionType = 'INCOME' | 'EXPENSE' | 'TRANSFER';

export interface Category {
  id: string;
  name: string;
  type: 'INCOME' | 'EXPENSE' | 'BOTH';
  color: string;
  parentId?: string; // For sub-categories
}

export interface TransactionFlag {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string; // lucide icon name
  isArchived: boolean;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: TransactionType;
  categoryIds: string[];
  sourceAccountId: string;
  destinationAccountId?: string;
  flagIds: string[]; // Replaces boolean flags
  attachments?: string[];
}

export type Frequency = 'WEEKLY' | 'MONTHLY' | 'YEARLY';

export interface RecurringTransaction {
  id: string;
  description: string;
  amount: number;
  type: TransactionType;
  categoryIds: string[];
  sourceAccountId: string;
  destinationAccountId?: string;
  frequency: Frequency;
  startDate: string;
  nextDueDate: string;
  reminderDaysBefore: number;
  isActive: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar?: string;
}

export interface AppSettings {
  currency: string;
  country: string;
  theme: 'light' | 'dark' | 'system';
  isPrivacyMode: boolean; // Hides amounts in lists
}

interface FinanceContextType {
  accounts: Account[];
  transactions: Transaction[];
  categories: Category[];
  recurringTransactions: RecurringTransaction[];
  flags: TransactionFlag[];
  userProfile: UserProfile;
  settings: AppSettings;
  
  addAccount: (account: Omit<Account, 'id'>) => void;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: string) => void;
  updateCategory: (id: string, category: Partial<Category>) => void;
  addRecurringTransaction: (transaction: Omit<RecurringTransaction, 'id' | 'nextDueDate'>) => void;
  deleteRecurringTransaction: (id: string) => void;
  
  // Flag Management
  addFlag: (flag: Omit<TransactionFlag, 'id' | 'isArchived'>) => void;
  archiveFlag: (id: string) => void;
  restoreFlag: (id: string) => void;

  // Settings & Profile
  updateUserProfile: (profile: Partial<UserProfile>) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;

  getNetWorth: () => number;
  getAssetsTotal: () => number;
  getLiabilitiesTotal: () => number;
  getCategoryName: (id: string) => string;
  processRecurringTransactions: () => void;
  formatAmount: (amount: number) => string;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

// Initial Mock Data
const INITIAL_ACCOUNTS: Account[] = [
  { id: '1', name: 'HDFC Savings', type: 'BANK', balance: 12450.00, bankName: 'HDFC Bank', accountNumber: '**** 4582', color: 'bg-blue-600' },
  { id: '2', name: 'Axis Salary', type: 'BANK', balance: 4850.00, bankName: 'Axis Bank', accountNumber: '**** 9921', color: 'bg-emerald-600' },
  { id: '3', name: 'Regalia Gold', type: 'CREDIT_CARD', balance: 1240.50, bankName: 'HDFC Bank', accountNumber: '**** 1102', color: 'bg-slate-800' },
  { id: '4', name: 'Home Loan', type: 'LOAN_PAYABLE', balance: 45000.00, bankName: 'SBI', accountNumber: '**** 3341', color: 'bg-indigo-600' },
  { id: '5', name: 'Friend Loan', type: 'LOAN_RECEIVABLE', balance: 500.00, bankName: 'Personal', color: 'bg-purple-600' },
];

const INITIAL_CATEGORIES: Category[] = [
  // Food & Drink
  { id: '1', name: 'Food & Drink', type: 'EXPENSE', color: 'bg-orange-500' },
  { id: '1-1', name: 'Restaurants', type: 'EXPENSE', color: 'bg-orange-400', parentId: '1' },
  { id: '1-2', name: 'Dining', type: 'EXPENSE', color: 'bg-orange-400', parentId: '1' },
  { id: '1-3', name: 'Swiggy/Online Apps', type: 'EXPENSE', color: 'bg-orange-400', parentId: '1' },
  { id: '1-4', name: 'Bakery', type: 'EXPENSE', color: 'bg-orange-400', parentId: '1' },
  
  // Transport
  { id: '2', name: 'Transport', type: 'EXPENSE', color: 'bg-blue-500' },
  { id: '2-1', name: 'Fuel', type: 'EXPENSE', color: 'bg-blue-400', parentId: '2' },
  { id: '2-2', name: 'Public Transport', type: 'EXPENSE', color: 'bg-blue-400', parentId: '2' },
  
  // Utilities
  { id: '3', name: 'Utilities', type: 'EXPENSE', color: 'bg-yellow-500' },
  { id: '3-1', name: 'Electricity', type: 'EXPENSE', color: 'bg-yellow-400', parentId: '3' },
  { id: '3-2', name: 'Water', type: 'EXPENSE', color: 'bg-yellow-400', parentId: '3' },
  { id: '3-3', name: 'Internet', type: 'EXPENSE', color: 'bg-yellow-400', parentId: '3' },

  // Income
  { id: '4', name: 'Salary', type: 'INCOME', color: 'bg-green-500' },
  { id: '5', name: 'Freelance', type: 'INCOME', color: 'bg-teal-500' },
  
  // Others
  { id: '6', name: 'Entertainment', type: 'EXPENSE', color: 'bg-purple-500' },
  { id: '7', name: 'Investment', type: 'BOTH', color: 'bg-indigo-500' },
];

const INITIAL_FLAGS: TransactionFlag[] = [
  { id: '1', name: 'Capital Expense', description: 'Large purchases like TV, Laptop', color: 'amber', icon: 'MonitorPlay', isArchived: false },
  { id: '2', name: 'Trip / Travel', description: 'Vacations, flights, hotels', color: 'sky', icon: 'Plane', isArchived: false },
  { id: '3', name: 'Savings / Investment', description: 'Mutual funds, stocks, deposits', color: 'emerald', icon: 'TrendingUp', isArchived: false },
];

const INITIAL_RECURRING: RecurringTransaction[] = [
  { 
    id: '1', 
    description: 'Netflix Subscription', 
    amount: 15.99, 
    type: 'EXPENSE', 
    categoryIds: ['5'], 
    sourceAccountId: '3', 
    destinationAccountId: undefined,
    frequency: 'MONTHLY', 
    startDate: '2023-10-23', 
    nextDueDate: format(addMonths(new Date(), 1), 'yyyy-MM-dd'), 
    reminderDaysBefore: 3, 
    isActive: true 
  }
];

const INITIAL_PROFILE: UserProfile = {
  name: 'John Doe',
  email: 'john@example.com',
};

const INITIAL_SETTINGS: AppSettings = {
  currency: 'USD',
  country: 'United States',
  theme: 'light',
  isPrivacyMode: false,
};

export function FinanceProvider({ children }: { children: ReactNode }) {
  // Load from localStorage or use initial
  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem('accounts');
    return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('transactions');
    return saved ? JSON.parse(saved) : [];
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });
  const [recurringTransactions, setRecurringTransactions] = useState<RecurringTransaction[]>(() => {
    const saved = localStorage.getItem('recurringTransactions');
    return saved ? JSON.parse(saved) : INITIAL_RECURRING;
  });
  const [flags, setFlags] = useState<TransactionFlag[]>(() => {
    const saved = localStorage.getItem('flags');
    return saved ? JSON.parse(saved) : INITIAL_FLAGS;
  });
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('userProfile');
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  // Persist to localStorage
  useEffect(() => { localStorage.setItem('accounts', JSON.stringify(accounts)); }, [accounts]);
  useEffect(() => { localStorage.setItem('transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('categories', JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem('recurringTransactions', JSON.stringify(recurringTransactions)); }, [recurringTransactions]);
  useEffect(() => { localStorage.setItem('flags', JSON.stringify(flags)); }, [flags]);
  useEffect(() => { localStorage.setItem('userProfile', JSON.stringify(userProfile)); }, [userProfile]);
  useEffect(() => { localStorage.setItem('settings', JSON.stringify(settings)); }, [settings]);

  // Apply Theme
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    if (settings.theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(settings.theme);
    }
  }, [settings.theme]);

  const addAccount = (account: Omit<Account, 'id'>) => {
    const newAccount = { ...account, id: Math.random().toString(36).substr(2, 9) };
    setAccounts([...accounts, newAccount]);
  };

  const addCategory = (category: Omit<Category, 'id'>) => {
    const newCategory = { ...category, id: Math.random().toString(36).substr(2, 9) };
    setCategories([...categories, newCategory]);
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id && c.parentId !== id));
  };

  const updateCategory = (id: string, category: Partial<Category>) => {
    setCategories(prev => prev.map(c => c.id === id ? { ...c, ...category } : c));
  };

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction = { ...transaction, id: Math.random().toString(36).substr(2, 9) };
    setTransactions(prev => [newTransaction, ...prev]);
    updateAccountBalances(newTransaction);
  };

  const updateAccountBalances = (transaction: Transaction) => {
    setAccounts(prevAccounts => {
      return prevAccounts.map(acc => {
        if (acc.id === transaction.sourceAccountId) {
          if (transaction.type === 'EXPENSE') {
            if (acc.type === 'CREDIT_CARD' || acc.type === 'LOAN_PAYABLE') {
               return { ...acc, balance: acc.balance + transaction.amount };
            } else {
               return { ...acc, balance: acc.balance - transaction.amount };
            }
          } else if (transaction.type === 'INCOME') {
            if (acc.type === 'CREDIT_CARD' || acc.type === 'LOAN_PAYABLE') {
               return { ...acc, balance: acc.balance - transaction.amount };
            } else {
               return { ...acc, balance: acc.balance + transaction.amount };
            }
          } else if (transaction.type === 'TRANSFER') {
            if (acc.type === 'CREDIT_CARD' || acc.type === 'LOAN_PAYABLE') {
               return { ...acc, balance: acc.balance + transaction.amount };
            } else {
               return { ...acc, balance: acc.balance - transaction.amount };
            }
          }
        }

        if (transaction.type === 'TRANSFER' && acc.id === transaction.destinationAccountId) {
          if (acc.type === 'CREDIT_CARD' || acc.type === 'LOAN_PAYABLE') {
             return { ...acc, balance: acc.balance - transaction.amount };
          } else {
             return { ...acc, balance: acc.balance + transaction.amount };
          }
        }

        return acc;
      });
    });
  };

  const addRecurringTransaction = (transaction: Omit<RecurringTransaction, 'id' | 'nextDueDate'>) => {
    const newRecurring = { 
      ...transaction, 
      id: Math.random().toString(36).substr(2, 9),
      nextDueDate: transaction.startDate // Initial due date is start date
    };
    setRecurringTransactions([...recurringTransactions, newRecurring]);
  };

  const deleteRecurringTransaction = (id: string) => {
    setRecurringTransactions(prev => prev.filter(t => t.id !== id));
  };

  // Flag Management
  const addFlag = (flag: Omit<TransactionFlag, 'id' | 'isArchived'>) => {
    const newFlag = { ...flag, id: Math.random().toString(36).substr(2, 9), isArchived: false };
    setFlags([...flags, newFlag]);
  };

  const archiveFlag = (id: string) => {
    setFlags(prev => prev.map(f => f.id === id ? { ...f, isArchived: true } : f));
  };

  const restoreFlag = (id: string) => {
    setFlags(prev => prev.map(f => f.id === id ? { ...f, isArchived: false } : f));
  };

  // Settings & Profile
  const updateUserProfile = (profile: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...profile }));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const processRecurringTransactions = () => {
    const today = new Date();
    let newTransactions: Transaction[] = [];
    let updatedRecurring = [...recurringTransactions];

    updatedRecurring = updatedRecurring.map(recurring => {
      if (!recurring.isActive) return recurring;

      let nextDue = parseISO(recurring.nextDueDate);
      let processed = false;

      // Check if due date is today or in the past
      if (isBefore(nextDue, today) || format(nextDue, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) {
        // Create Transaction
        const newTx: Transaction = {
          id: Math.random().toString(36).substr(2, 9),
          date: recurring.nextDueDate,
          description: recurring.description,
          amount: recurring.amount,
          type: recurring.type,
          categoryIds: recurring.categoryIds,
          sourceAccountId: recurring.sourceAccountId,
          destinationAccountId: recurring.destinationAccountId,
          flagIds: [], // Default to no flags for recurring
        };
        newTransactions.push(newTx);
        updateAccountBalances(newTx); // Apply balance change immediately

        // Calculate next due date
        let newNextDue = nextDue;
        if (recurring.frequency === 'WEEKLY') newNextDue = addWeeks(nextDue, 1);
        if (recurring.frequency === 'MONTHLY') newNextDue = addMonths(nextDue, 1);
        if (recurring.frequency === 'YEARLY') newNextDue = addYears(nextDue, 1);

        return { ...recurring, nextDueDate: format(newNextDue, 'yyyy-MM-dd') };
      }
      return recurring;
    });

    if (newTransactions.length > 0) {
      setTransactions(prev => [...newTransactions, ...prev]);
      setRecurringTransactions(updatedRecurring);
      console.log('Processed recurring transactions:', newTransactions.length);
    }
  };

  // Check for recurring transactions on mount
  useEffect(() => {
    processRecurringTransactions();
  }, []);

  const getAssetsTotal = () => {
    return accounts
      .filter(a => a.type === 'BANK' || a.type === 'LOAN_RECEIVABLE' || a.type === 'WALLET')
      .reduce((sum, a) => sum + a.balance, 0);
  };

  const getLiabilitiesTotal = () => {
    return accounts
      .filter(a => a.type === 'CREDIT_CARD' || a.type === 'LOAN_PAYABLE')
      .reduce((sum, a) => sum + a.balance, 0);
  };

  const getNetWorth = () => {
    return getAssetsTotal() - getLiabilitiesTotal();
  };

  const getCategoryName = (id: string) => {
    const category = categories.find(c => c.id === id);
    if (!category) return 'Uncategorized';
    
    if (category.parentId) {
      const parent = categories.find(p => p.id === category.parentId);
      if (parent) return `${parent.name} > ${category.name}`;
    }
    
    return category.name;
  };

  const formatAmount = (amount: number) => {
    if (settings.isPrivacyMode) return '****';
    return amount.toLocaleString('en-US', { style: 'currency', currency: settings.currency });
  };

  return (
    <FinanceContext.Provider value={{ 
      accounts, 
      transactions, 
      categories,
      recurringTransactions,
      flags,
      userProfile,
      settings,
      addAccount, 
      addTransaction,
      addCategory,
      deleteCategory,
      updateCategory,
      addRecurringTransaction,
      deleteRecurringTransaction,
      addFlag,
      archiveFlag,
      restoreFlag,
      updateUserProfile,
      updateSettings,
      getNetWorth,
      getAssetsTotal,
      getLiabilitiesTotal,
      getCategoryName,
      processRecurringTransactions,
      formatAmount
    }}>
      {children}
    </FinanceContext.Provider>
  );
}

export function useFinance() {
  const context = useContext(FinanceContext);
  if (context === undefined) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
}
