import React, { useState } from 'react';
import { X, Calendar, CreditCard, RefreshCw, Bell } from 'lucide-react';
import { useFinance, TransactionType, Frequency } from '../context/FinanceContext';
import { cn } from '../lib/utils';

interface RecurringTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function RecurringTransactionModal({ isOpen, onClose }: RecurringTransactionModalProps) {
  const { accounts, categories, addRecurringTransaction, settings } = useFinance();

  // Form State
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('EXPENSE');
  const [frequency, setFrequency] = useState<Frequency>('MONTHLY');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [reminderDays, setReminderDays] = useState('3');
  const [sourceAccountId, setSourceAccountId] = useState(accounts[0]?.id || '');
  const [selectedCategoryId, setSelectedCategoryId] = useState(categories[0]?.id || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !sourceAccountId || !description) return;

    addRecurringTransaction({
      description,
      amount: parseFloat(amount),
      type,
      frequency,
      startDate,
      reminderDaysBefore: parseInt(reminderDays),
      sourceAccountId,
      categoryIds: [selectedCategoryId],
      isActive: true
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setDescription('');
    setAmount('');
    setFrequency('MONTHLY');
    setStartDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <RefreshCw size={20} className="text-indigo-600" />
            Recurring Transaction
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Netflix, Rent, Insurance"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Amount */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Amount</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                  {new Intl.NumberFormat('en-US', { style: 'currency', currency: settings.currency }).format(0).replace(/\d/g, '').replace(/[.,]/g, '').trim()}
                </span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                  step="0.01"
                  min="0"
                />
              </div>
            </div>

            {/* Frequency */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Frequency</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as Frequency)}
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
              >
                <option value="WEEKLY">Weekly</option>
                <option value="MONTHLY">Monthly</option>
                <option value="YEARLY">Yearly</option>
              </select>
            </div>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Start Date</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                required
              />
            </div>
          </div>

          {/* Account & Category */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Account</label>
              <select
                value={sourceAccountId}
                onChange={(e) => setSourceAccountId(e.target.value)}
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              >
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>{acc.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Category</label>
              <select
                value={selectedCategoryId}
                onChange={(e) => setSelectedCategoryId(e.target.value)}
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              >
                {categories.filter(c => c.type === 'EXPENSE' || c.type === 'BOTH').map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Reminder */}
          <div className="bg-indigo-50 p-4 rounded-xl flex items-center gap-4">
            <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
              <Bell size={20} />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-semibold text-indigo-900 uppercase tracking-wider mb-1">Remind Me</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={reminderDays}
                  onChange={(e) => setReminderDays(e.target.value)}
                  className="w-12 px-2 py-1 bg-white border border-indigo-200 rounded-lg text-center text-sm font-bold text-indigo-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                  min="0"
                  max="30"
                />
                <span className="text-sm text-indigo-700">days before due date</span>
              </div>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
          >
            Create Recurring Rule
          </button>
        </form>
      </div>
    </div>
  );
}
