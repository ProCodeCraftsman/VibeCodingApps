import React, { useState, useRef } from 'react';
import { 
  X, Calendar, CreditCard, FileText, Paperclip, 
  Plus, Check, AlertCircle, HelpCircle
} from 'lucide-react';
import { useFinance, TransactionType } from '../context/FinanceContext';
import { cn } from '../lib/utils';
import * as Icons from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TransactionModal({ isOpen, onClose }: TransactionModalProps) {
  const { accounts, categories, flags, addTransaction, addCategory, settings } = useFinance();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [type, setType] = useState<TransactionType>('EXPENSE');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [sourceAccountId, setSourceAccountId] = useState(accounts[0]?.id || '');
  const [destinationAccountId, setDestinationAccountId] = useState(accounts[1]?.id || '');
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [selectedFlagIds, setSelectedFlagIds] = useState<string[]>([]);
  
  // Attachments
  const [attachments, setAttachments] = useState<string[]>([]);

  // New Category State
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Validation State
  const [showValidation, setShowValidation] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowValidation(true);

    if (!amount || parseFloat(amount) <= 0 || !sourceAccountId) {
      return;
    }

    addTransaction({
      date,
      description,
      amount: parseFloat(amount),
      type,
      categoryIds: selectedCategoryIds,
      sourceAccountId,
      destinationAccountId: type === 'TRANSFER' ? destinationAccountId : undefined,
      flagIds: selectedFlagIds,
      attachments
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setAmount('');
    setDescription('');
    setSelectedCategoryIds([]);
    setSelectedFlagIds([]);
    setAttachments([]);
    setShowValidation(false);
  };

  const toggleCategory = (id: string) => {
    setSelectedCategoryIds(prev => 
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  const toggleFlag = (id: string) => {
    setSelectedFlagIds(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const [activeMainCategoryId, setActiveMainCategoryId] = useState<string | null>(null);

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      addCategory({
        name: newCategoryName,
        type: type === 'TRANSFER' ? 'BOTH' : type,
        color: 'bg-slate-500', // Default color
        parentId: activeMainCategoryId || undefined
      });
      setNewCategoryName('');
      setIsAddingCategory(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files).map((f: File) => f.name);
      setAttachments([...attachments, ...newFiles]);
    }
  };

  // Helper to render dynamic icon
  const renderIcon = (iconName: string, size: number) => {
    const Icon = (Icons as any)[iconName] || HelpCircle;
    return <Icon size={size} />;
  };

  const isAmountInvalid = showValidation && (!amount || parseFloat(amount) <= 0);

  const mainCategories = categories.filter(c => !c.parentId && (c.type === type || c.type === 'BOTH'));
  const subCategories = activeMainCategoryId 
    ? categories.filter(c => c.parentId === activeMainCategoryId && (c.type === type || c.type === 'BOTH'))
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in duration-200 my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">New Transaction</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row">
          {/* Left Column: Main Details */}
          <div className="flex-1 p-6 space-y-6 border-r border-slate-100 dark:border-slate-800">
            {/* Type Selector */}
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              {(['INCOME', 'EXPENSE', 'TRANSFER'] as TransactionType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setType(t);
                    setActiveMainCategoryId(null);
                  }}
                  className={cn(
                    "flex-1 py-2 text-sm font-medium rounded-lg transition-all",
                    type === t 
                      ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm" 
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  )}
                >
                  {t.charAt(0) + t.slice(1).toLowerCase()}
                </button>
              ))}
            </div>

            {/* Amount */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xl">
                  {new Intl.NumberFormat('en-US', { style: 'currency', currency: settings.currency }).format(0).replace(/\d/g, '').replace(/[.,]/g, '').trim()}
                </span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className={cn(
                    "w-full pl-10 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border rounded-xl text-3xl font-bold text-slate-900 dark:text-white placeholder:text-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none transition-all",
                    isAmountInvalid ? "border-rose-500 focus:ring-rose-500" : "border-slate-200 dark:border-slate-700"
                  )}
                  autoFocus
                  step="0.01"
                  min="0"
                />
              </div>
              {isAmountInvalid && (
                <p className="text-rose-500 text-xs mt-1 flex items-center gap-1">
                  <AlertCircle size={12} />
                  Amount is mandatory
                </p>
              )}
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Date</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>
            </div>

            {/* Accounts */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                  {type === 'TRANSFER' ? 'From Account' : 'Account'}
                </label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <select
                    value={sourceAccountId}
                    onChange={(e) => setSourceAccountId(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                  >
                    {accounts.map(acc => (
                      <option key={acc.id} value={acc.id}>{acc.name} (${acc.balance})</option>
                    ))}
                  </select>
                </div>
              </div>

              {type === 'TRANSFER' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">To Account</label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <select
                      value={destinationAccountId}
                      onChange={(e) => setDestinationAccountId(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                    >
                      {accounts.map(acc => (
                        <option key={acc.id} value={acc.id} disabled={acc.id === sourceAccountId}>
                          {acc.name} (${acc.balance})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Description</label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 text-slate-400" size={18} />
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What was this for?"
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-24"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Meta & Categorization */}
          <div className="w-full md:w-80 bg-slate-50 dark:bg-slate-900/50 p-6 space-y-6 flex flex-col">
            
            {/* Categories */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  {activeMainCategoryId ? 'Sub-categories' : 'Categories'}
                </label>
                <button 
                  type="button" 
                  onClick={() => setIsAddingCategory(!isAddingCategory)}
                  className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700 flex items-center gap-1"
                >
                  <Plus size={12} /> {isAddingCategory ? 'Cancel' : 'Add New'}
                </button>
              </div>

              {isAddingCategory && (
                <div className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    placeholder={activeMainCategoryId ? "Sub-category name" : "Main category name"}
                    className="flex-1 px-3 py-1.5 text-sm border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    autoFocus
                  />
                  <button 
                    type="button"
                    onClick={handleAddCategory}
                    className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700"
                  >
                    Add
                  </button>
                </div>
              )}

              {activeMainCategoryId && (
                <button 
                  type="button"
                  onClick={() => setActiveMainCategoryId(null)}
                  className="text-xs text-slate-500 hover:text-indigo-600 mb-2 flex items-center gap-1"
                >
                  ← Back to Main Categories
                </button>
              )}

              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto pr-2">
                {!activeMainCategoryId ? (
                  mainCategories.map(category => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setActiveMainCategoryId(category.id)}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-xs font-medium border transition-all flex items-center gap-1.5",
                        "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-200"
                      )}
                    >
                      {category.name}
                      <Icons.ChevronRight size={12} />
                    </button>
                  ))
                ) : (
                  subCategories.map(category => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => toggleCategory(category.id)}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-xs font-medium border transition-all flex items-center gap-1.5",
                        selectedCategoryIds.includes(category.id)
                          ? "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-200"
                      )}
                    >
                      {selectedCategoryIds.includes(category.id) && <Check size={12} />}
                      {category.name}
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Flags */}
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Flags</label>
              
              {flags.filter(f => !f.isArchived || selectedFlagIds.includes(f.id)).map(flag => (
                <button
                  key={flag.id}
                  type="button"
                  onClick={() => toggleFlag(flag.id)}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left",
                    selectedFlagIds.includes(flag.id) 
                      ? `bg-${flag.color}-50 dark:bg-${flag.color}-900/20 border-${flag.color}-200 dark:border-${flag.color}-800 text-${flag.color}-800 dark:text-${flag.color}-200` 
                      : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-200"
                  )}
                >
                  <div className={cn(
                    "p-2 rounded-lg", 
                    selectedFlagIds.includes(flag.id) 
                      ? `bg-${flag.color}-100 dark:bg-${flag.color}-900/50 text-${flag.color}-600 dark:text-${flag.color}-400` 
                      : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
                  )}>
                    {renderIcon(flag.icon, 18)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{flag.name}</p>
                    <p className="text-xs opacity-70">{flag.description}</p>
                  </div>
                  {selectedFlagIds.includes(flag.id) && <Check size={16} className={`ml-auto text-${flag.color}-600`} />}
                </button>
              ))}
            </div>

            {/* Attachments */}
            <div className="mt-auto">
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Attachments</label>
              <div className="space-y-2">
                {attachments.map((file, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-200 dark:border-slate-700">
                    <Paperclip size={14} />
                    <span className="truncate flex-1">{file}</span>
                    <button type="button" onClick={() => setAttachments(attachments.filter((_, i) => i !== idx))} className="text-slate-400 hover:text-rose-500">
                      <X size={14} />
                    </button>
                  </div>
                ))}
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-2 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-500 dark:text-slate-400 hover:border-indigo-300 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2"
                >
                  <Paperclip size={16} />
                  Attach Receipt
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  multiple 
                  onChange={handleFileChange} 
                />
              </div>
            </div>

            {/* Submit Button */}
            <button 
              type="submit"
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 dark:shadow-none mt-4"
            >
              Save Transaction
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
