import React, { useState } from 'react';
import { 
  User, Bell, Shield, CreditCard, HelpCircle, LogOut, 
  Moon, Sun, Monitor, Eye, EyeOff, Flag, Archive, 
  RotateCcw, Plus, X, Globe, ChevronRight, ChevronDown, 
  Trash2, Edit2, Tag
} from 'lucide-react';
import { useFinance, TransactionFlag, Category } from '../context/FinanceContext';
import { cn } from '../lib/utils';
import * as Icons from 'lucide-react';

const CURRENCIES = [
  { code: 'USD', symbol: '$', country: 'United States' },
  { code: 'EUR', symbol: '€', country: 'European Union' },
  { code: 'GBP', symbol: '£', country: 'United Kingdom' },
  { code: 'INR', symbol: '₹', country: 'India' },
  { code: 'JPY', symbol: '¥', country: 'Japan' },
  { code: 'CAD', symbol: 'C$', country: 'Canada' },
  { code: 'AUD', symbol: 'A$', country: 'Australia' },
];

const ICONS_LIST = ['MonitorPlay', 'Plane', 'TrendingUp', 'ShoppingBag', 'Home', 'Car', 'Gift', 'Heart', 'Coffee', 'Zap'];

const COLORS = [
  { name: 'Slate', value: 'bg-slate-500' },
  { name: 'Red', value: 'bg-red-500' },
  { name: 'Orange', value: 'bg-orange-500' },
  { name: 'Amber', value: 'bg-amber-500' },
  { name: 'Emerald', value: 'bg-emerald-500' },
  { name: 'Sky', value: 'bg-sky-500' },
  { name: 'Violet', value: 'bg-violet-500' },
  { name: 'Rose', value: 'bg-rose-500' },
];

export function Settings() {
  const { 
    userProfile, updateUserProfile, 
    settings, updateSettings, 
    flags, addFlag, archiveFlag, restoreFlag,
    categories, addCategory, deleteCategory, updateCategory
  } = useFinance();

  // Flag Form State
  const [isAddingFlag, setIsAddingFlag] = useState(false);
  const [newFlag, setNewFlag] = useState<Partial<TransactionFlag>>({
    name: '',
    description: '',
    color: 'slate',
    icon: 'Flag'
  });

  // Category Management State
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategory, setNewCategory] = useState<Partial<Category>>({
    name: '',
    type: 'EXPENSE',
    color: 'bg-slate-500',
    parentId: undefined
  });
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);

  const toggleCategoryExpand = (id: string) => {
    setExpandedCategories(prev => 
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  const handleAddFlag = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFlag.name) {
      addFlag({
        name: newFlag.name,
        description: newFlag.description || '',
        color: newFlag.color || 'slate',
        icon: newFlag.icon || 'Flag'
      });
      setIsAddingFlag(false);
      setNewFlag({ name: '', description: '', color: 'slate', icon: 'Flag' });
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategory.name) {
      addCategory({
        name: newCategory.name,
        type: newCategory.type || 'EXPENSE',
        color: newCategory.color || 'bg-slate-500',
        parentId: newCategory.parentId
      });
      setIsAddingCategory(false);
      setNewCategory({ name: '', type: 'EXPENSE', color: 'bg-slate-500', parentId: undefined });
    }
  };

  const renderIcon = (iconName: string, size: number) => {
    const Icon = (Icons as any)[iconName] || Flag;
    return <Icon size={size} />;
  };

  const mainCategories = categories.filter(c => !c.parentId);
  const getSubCategories = (parentId: string) => categories.filter(c => c.parentId === parentId);

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Settings</h1>
        <p className="text-slate-500 dark:text-slate-400">Manage your account preferences and application settings.</p>
      </div>

      {/* Profile Section */}
      <section className="space-y-4">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">Profile</h2>
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 p-6">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-2xl font-bold">
              {userProfile.name.charAt(0)}
            </div>
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={userProfile.name}
                    onChange={(e) => updateUserProfile({ name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={userProfile.email}
                    onChange={(e) => updateUserProfile({ email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Preferences Section */}
      <section className="space-y-4">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">Preferences</h2>
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden divide-y divide-slate-100 dark:divide-slate-700">
          
          {/* Currency */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                <Globe size={20} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Currency & Region</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Select your local currency</p>
              </div>
            </div>
            <select
              value={settings.currency}
              onChange={(e) => updateSettings({ currency: e.target.value })}
              className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {CURRENCIES.map(c => (
                <option key={c.code} value={c.code}>{c.country} ({c.code} {c.symbol})</option>
              ))}
            </select>
          </div>

          {/* Theme */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-violet-50 dark:bg-violet-900/30 flex items-center justify-center text-violet-600 dark:text-violet-400">
                {settings.theme === 'light' ? <Sun size={20} /> : settings.theme === 'dark' ? <Moon size={20} /> : <Monitor size={20} />}
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Appearance</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Choose your preferred theme</p>
              </div>
            </div>
            <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-lg">
              {(['light', 'dark', 'system'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => updateSettings({ theme: t })}
                  className={cn(
                    "px-3 py-1.5 text-xs font-medium rounded-md transition-all capitalize",
                    settings.theme === t 
                      ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm" 
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Privacy Mode */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400">
                {settings.isPrivacyMode ? <EyeOff size={20} /> : <Eye size={20} />}
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Privacy Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Hide transaction amounts in lists</p>
              </div>
            </div>
            <button
              onClick={() => updateSettings({ isPrivacyMode: !settings.isPrivacyMode })}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                settings.isPrivacyMode ? "bg-indigo-600" : "bg-slate-200 dark:bg-slate-700"
              )}
            >
              <div className={cn(
                "w-4 h-4 rounded-full bg-white shadow-sm absolute top-1 transition-transform",
                settings.isPrivacyMode ? "left-7" : "left-1"
              )} />
            </button>
          </div>
        </div>
      </section>

      {/* Category Management Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Categories</h2>
          <button 
            onClick={() => setIsAddingCategory(!isAddingCategory)}
            className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700 flex items-center gap-1"
          >
            <Plus size={14} /> Add Category
          </button>
        </div>

        {isAddingCategory && (
          <form onSubmit={handleAddCategory} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-4 animate-in fade-in slide-in-from-top-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Category Name</label>
                <input
                  type="text"
                  placeholder="e.g., Food & Drink"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Parent Category (Optional)</label>
                <select
                  value={newCategory.parentId || ''}
                  onChange={(e) => setNewCategory({ ...newCategory, parentId: e.target.value || undefined })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">None (Main Category)</option>
                  {mainCategories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Type</label>
                <select
                  value={newCategory.type}
                  onChange={(e) => setNewCategory({ ...newCategory, type: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="EXPENSE">Expense</option>
                  <option value="INCOME">Income</option>
                  <option value="BOTH">Both</option>
                </select>
              </div>
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Color</label>
                <select
                  value={newCategory.color}
                  onChange={(e) => setNewCategory({ ...newCategory, color: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {COLORS.map(c => (
                    <option key={c.value} value={c.value}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddingCategory(false)}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-sm"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700"
                >
                  Save
                </button>
              </div>
            </div>
          </form>
        )}

        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
          <div className="divide-y divide-slate-100 dark:divide-slate-700">
            {mainCategories.map(category => {
              const subCats = getSubCategories(category.id);
              const isExpanded = expandedCategories.includes(category.id);
              
              return (
                <div key={category.id} className="group">
                  <div className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => toggleCategoryExpand(category.id)}
                        className={cn(
                          "p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-400 transition-all",
                          subCats.length === 0 && "invisible"
                        )}
                      >
                        {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                      </button>
                      <div className={cn("w-3 h-3 rounded-full", category.color)} />
                      <div>
                        <p className="text-sm font-medium text-slate-900 dark:text-white">{category.name}</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider">{category.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => deleteCategory(category.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  
                  {isExpanded && subCats.length > 0 && (
                    <div className="bg-slate-50/50 dark:bg-slate-900/30 pl-12 pr-4 py-2 space-y-1">
                      {subCats.map(sub => (
                        <div key={sub.id} className="flex items-center justify-between py-2 group/sub">
                          <div className="flex items-center gap-3">
                            <div className={cn("w-2 h-2 rounded-full opacity-60", sub.color)} />
                            <p className="text-sm text-slate-600 dark:text-slate-300">{sub.name}</p>
                          </div>
                          <button 
                            onClick={() => deleteCategory(sub.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 opacity-0 group-hover/sub:opacity-100 transition-opacity"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Flag Management Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Transaction Flags</h2>
          <button 
            onClick={() => setIsAddingFlag(!isAddingFlag)}
            className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700 flex items-center gap-1"
          >
            <Plus size={14} /> Add Flag
          </button>
        </div>

        {isAddingFlag && (
          <form onSubmit={handleAddFlag} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900 shadow-sm space-y-4 animate-in fade-in slide-in-from-top-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Flag Name (e.g., 'Tax Deductible')"
                value={newFlag.name}
                onChange={(e) => setNewFlag({ ...newFlag, name: e.target.value })}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <input
                type="text"
                placeholder="Description"
                value={newFlag.description}
                onChange={(e) => setNewFlag({ ...newFlag, description: e.target.value })}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="flex gap-4">
              <select
                value={newFlag.color}
                onChange={(e) => setNewFlag({ ...newFlag, color: e.target.value })}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="slate">Slate (Gray)</option>
                <option value="red">Red</option>
                <option value="orange">Orange</option>
                <option value="amber">Amber</option>
                <option value="emerald">Emerald</option>
                <option value="sky">Sky (Blue)</option>
                <option value="violet">Violet</option>
                <option value="rose">Rose</option>
              </select>
              <select
                value={newFlag.icon}
                onChange={(e) => setNewFlag({ ...newFlag, icon: e.target.value })}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {ICONS_LIST.map(icon => (
                  <option key={icon} value={icon}>{icon}</option>
                ))}
              </select>
              <div className="flex-1 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddingFlag(false)}
                  className="px-4 py-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-sm"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700"
                >
                  Save Flag
                </button>
              </div>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {flags.map(flag => (
            <div 
              key={flag.id} 
              className={cn(
                "p-4 rounded-xl border flex items-center justify-between group transition-all",
                flag.isArchived 
                  ? "bg-slate-50 dark:bg-slate-900 border-slate-100 dark:border-slate-800 opacity-60" 
                  : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  "p-2 rounded-lg",
                  `bg-${flag.color}-100 dark:bg-${flag.color}-900/30 text-${flag.color}-600 dark:text-${flag.color}-400`
                )}>
                  {renderIcon(flag.icon, 18)}
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white flex items-center gap-2">
                    {flag.name}
                    {flag.isArchived && <span className="text-[10px] bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded text-slate-500">Archived</span>}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{flag.description}</p>
                </div>
              </div>
              <button
                onClick={() => flag.isArchived ? restoreFlag(flag.id) : archiveFlag(flag.id)}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                title={flag.isArchived ? "Restore" : "Archive"}
              >
                {flag.isArchived ? <RotateCcw size={16} /> : <Archive size={16} />}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Other Sections (Placeholder) */}
      <section className="space-y-4">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">Support</h2>
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
          <button className="w-full flex items-center gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left">
            <div className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400">
              <HelpCircle size={20} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-slate-900 dark:text-white">Help & Support</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">FAQs and contact support</p>
            </div>
          </button>
        </div>
      </section>

      <div className="pt-4">
        <button className="flex items-center gap-2 text-rose-600 font-medium hover:text-rose-700 px-4 py-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors">
          <LogOut size={20} />
          Sign Out
        </button>
      </div>
    </div>
  );
}
