import React, { useState } from 'react';
import { ArrowUpRight, ArrowDownRight, DollarSign, Wallet, CreditCard, TrendingUp, Bell, Calendar, CheckCircle2, Bot, Sparkles } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn } from '../lib/utils';
import { useFinance } from '../context/FinanceContext';
import { format, parseISO, differenceInDays } from 'date-fns';
import { AIChatModal } from '../components/AIChatModal';

export function Dashboard() {
  const { transactions, accounts, getNetWorth, getAssetsTotal, getLiabilitiesTotal, recurringTransactions, formatAmount, settings } = useFinance();
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);

  // Calculate Stats
  const netWorth = getNetWorth();
  const assets = getAssetsTotal();
  const liabilities = getLiabilitiesTotal();
  
  // Mock Monthly Change (In a real app, calculate from previous month)
  const stats = [
    { label: 'Net Worth', value: netWorth, change: '+2.5%', trend: 'up', icon: Wallet },
    { label: 'Total Assets', value: assets, change: '+12%', trend: 'up', icon: ArrowDownRight },
    { label: 'Total Liabilities', value: liabilities, change: '-5%', trend: 'down', icon: ArrowUpRight },
    { label: 'Monthly Savings', value: 4850.00, change: '+8%', trend: 'up', icon: DollarSign },
  ];

  const recentTransactions = transactions.slice(0, 5);

  // Get Upcoming Recurring
  const upcomingRecurring = recurringTransactions
    .filter(t => t.isActive)
    .sort((a, b) => new Date(a.nextDueDate).getTime() - new Date(b.nextDueDate).getTime())
    .slice(0, 3);

  const getDaysDueLabel = (dateStr: string) => {
    const days = differenceInDays(parseISO(dateStr), new Date());
    if (days < 0) return 'Overdue';
    if (days === 0) return 'Due Today';
    if (days === 1) return 'Tomorrow';
    return `In ${days} days`;
  };

  // Mock Chart Data
  const chartData = [
    { name: 'Jan', income: 4000, expense: 2400 },
    { name: 'Feb', income: 3000, expense: 1398 },
    { name: 'Mar', income: 2000, expense: 9800 },
    { name: 'Apr', income: 2780, expense: 3908 },
    { name: 'May', income: 1890, expense: 4800 },
    { name: 'Jun', income: 2390, expense: 3800 },
    { name: 'Jul', income: 3490, expense: 4300 },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
        <p className="text-slate-500 dark:text-slate-400">Welcome back, here's your financial overview.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-2 rounded-lg", stat.trend === 'up' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400')}>
                <stat.icon size={20} />
              </div>
              <div className={cn("flex items-center text-xs font-medium px-2 py-1 rounded-full", stat.trend === 'up' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300' : 'bg-rose-50 dark:bg-rose-900/30 text-rose-700 dark:text-rose-300')}>
                {stat.trend === 'up' ? <TrendingUp size={12} className="mr-1" /> : <TrendingUp size={12} className="mr-1 rotate-180" />}
                {stat.change}
              </div>
            </div>
            <h3 className="text-slate-500 dark:text-slate-400 text-sm font-medium">{stat.label}</h3>
            <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1 font-mono">
              {formatAmount(stat.value)}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart Area */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 min-h-[400px]">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Cash Flow</h2>
            <select className="bg-slate-50 dark:bg-slate-900 border-none text-sm text-slate-600 dark:text-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
              <option>Last 6 Months</option>
              <option>This Year</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" className="dark:stroke-slate-700" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#64748b', fontSize: 12}} 
                  tickFormatter={(value) => settings.isPrivacyMode ? '****' : `$${value}`} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ fontSize: '12px', fontWeight: 500 }}
                  formatter={(value: number) => [settings.isPrivacyMode ? '****' : `$${value}`, '']}
                />
                <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" />
                <Area type="monotone" dataKey="expense" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorExpense)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          {/* AI Assistant Widget */}
          <div 
            onClick={() => setIsAIModalOpen(true)}
            className="bg-gradient-to-br from-indigo-600 to-violet-700 p-6 rounded-2xl shadow-lg text-white cursor-pointer hover:shadow-xl hover:scale-[1.02] transition-all relative overflow-hidden group"
          >
            <div className="absolute -top-4 -right-4 opacity-10 group-hover:opacity-20 transition-opacity rotate-12">
              <Sparkles size={120} />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm shadow-inner">
                  <Bot size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg leading-tight">AI Assistant</h3>
                  <p className="text-indigo-200 text-xs font-medium">Smart Transaction Logger</p>
                </div>
              </div>
              <p className="text-indigo-100 text-sm mb-5 leading-relaxed">
                "Spent $50 on dinner..." <br/>
                Tell me what happened, and I'll log it for you automatically.
              </p>
              <button className="bg-white text-indigo-700 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:bg-indigo-50 transition-colors w-full flex items-center justify-center gap-2">
                <Sparkles size={16} />
                Chat with AI
              </button>
            </div>
          </div>

          {/* Upcoming Reminders */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Bell size={20} className="text-indigo-500" />
                Upcoming
              </h2>
              <button className="text-sm text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700">Manage</button>
            </div>
            <div className="space-y-4">
              {upcomingRecurring.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">No upcoming payments.</p>
              ) : (
                upcomingRecurring.map(item => (
                  <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-700">
                    <div className="bg-white dark:bg-slate-800 p-2 rounded-lg text-slate-500 dark:text-slate-400 shadow-sm">
                      <Calendar size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{item.description}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        {getDaysDueLabel(item.nextDueDate)} • {format(parseISO(item.nextDueDate), 'MMM d')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                        {formatAmount(item.amount)}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Recent Activity</h2>
              <button className="text-sm text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700">View All</button>
            </div>
            <div className="space-y-6">
              {recentTransactions.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400">No recent transactions.</p>
              ) : (
                recentTransactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between group cursor-pointer">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        <CreditCard size={18} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate max-w-[120px]">{tx.description}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{tx.date}</p>
                      </div>
                    </div>
                    <div className={cn("text-sm font-semibold font-mono", tx.type === 'INCOME' ? "text-emerald-600 dark:text-emerald-400" : "text-slate-900 dark:text-white")}>
                      {tx.type === 'INCOME' ? '+' : ''}{formatAmount(tx.amount)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      <AIChatModal isOpen={isAIModalOpen} onClose={() => setIsAIModalOpen(false)} />
    </div>
  );
}
