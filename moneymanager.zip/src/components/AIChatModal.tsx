import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { useFinance } from '../context/FinanceContext';
import { cn } from '../lib/utils';

interface AIChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export function AIChatModal({ isOpen, onClose }: AIChatModalProps) {
  const { accounts, categories, flags, addTransaction } = useFinance();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your financial assistant. Tell me about your recent spending or income, and I'll log it for you. For example: 'Spent $50 on groceries at Whole Foods using my Credit Card'."
    }
  ]);
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const accountsContext = accounts.map(a => `${a.name} (ID: ${a.id}, Type: ${a.type})`).join(', ');
      const categoriesContext = categories.map(c => {
        const parent = c.parentId ? categories.find(p => p.id === c.parentId) : null;
        return `- ${c.name} (ID: ${c.id}, Type: ${c.type}${parent ? `, Parent: ${parent.name}` : ''})`;
      }).join('\n');
      const flagsContext = flags.filter(f => !f.isArchived).map(f => `${f.name} (ID: ${f.id})`).join(', ');

      const prompt = `
        You are a smart financial assistant. Your goal is to parse natural language input into structured transaction data.
        
        Current Date: ${new Date().toISOString().split('T')[0]}
        
        Available Accounts:
        ${accountsContext}
        
        Available Categories (Hierarchical):
        ${categoriesContext}

        Available Flags:
        ${flagsContext}
        
        User Input: "${userMessage.content}"
        
        Instructions:
        1. Analyze the user's input to identify financial transactions.
        2. If the input describes one or more transactions, extract the details.
        3. Map the account names and category names to the provided IDs. 
        4. If a sub-category is mentioned (e.g., "Dining"), use its ID. If only a main category is mentioned (e.g., "Food & Drink"), use its ID or infer a sub-category if obvious.
        5. If an account is not specified, try to infer it or use the first available BANK account.
        6. Return a JSON object with the following structure:
        {
          "response": "A friendly confirmation message summarizing what you did, or a question if clarification is needed.",
          "transactions": [
            {
              "amount": number,
              "type": "INCOME" | "EXPENSE" | "TRANSFER",
              "date": "YYYY-MM-DD",
              "description": "string",
              "sourceAccountId": "string (ID)",
              "destinationAccountId": "string (ID, optional, for transfers)",
              "categoryIds": ["string (ID)"],
              "flagIds": ["string (ID)"]
            }
          ]
        }
        7. If the input is NOT a transaction (e.g., "Hello", "How are you?"), return a JSON with an empty "transactions" array and a conversational "response".
        8. Do NOT return markdown formatting (like \`\`\`json). Just return the raw JSON string.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      
      const responseText = response.text || "{}";
      
      // Clean up potential markdown code blocks
      const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      
      let data;
      try {
        data = JSON.parse(cleanJson);
      } catch (e) {
        console.error("Failed to parse JSON", e);
        data = { response: "I understood that, but had trouble processing the details. Could you try again?", transactions: [] };
      }

      if (data.transactions && data.transactions.length > 0) {
        data.transactions.forEach((tx: any) => {
          addTransaction({
            amount: tx.amount,
            type: tx.type,
            date: tx.date,
            description: tx.description,
            sourceAccountId: tx.sourceAccountId,
            destinationAccountId: tx.destinationAccountId,
            categoryIds: tx.categoryIds || [],
            flagIds: tx.flagIds || []
          });
        });
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response || "Processed your request."
      };

      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Sorry, I encountered an error processing your request. Please try again."
      }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg h-[600px] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-indigo-600 text-white">
          <div className="flex items-center gap-2">
            <Sparkles size={20} />
            <h2 className="font-semibold">AI Assistant</h2>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex gap-3 max-w-[85%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                msg.role === 'user' ? "bg-indigo-100 text-indigo-600" : "bg-emerald-100 text-emerald-600"
              )}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={cn(
                "p-3 rounded-2xl text-sm shadow-sm",
                msg.role === 'user' 
                  ? "bg-indigo-600 text-white rounded-tr-none" 
                  : "bg-white text-slate-700 rounded-tl-none border border-slate-100"
              )}>
                {msg.content}
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex gap-3 max-w-[85%]">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center flex-shrink-0">
                <Bot size={16} />
              </div>
              <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
                <Loader2 size={16} className="animate-spin text-slate-400" />
                <span className="text-xs text-slate-400">Thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t border-slate-100">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              disabled={isProcessing}
            />
            <button
              type="submit"
              disabled={!input.trim() || isProcessing}
              className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
