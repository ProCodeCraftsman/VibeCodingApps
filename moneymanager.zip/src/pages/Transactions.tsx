import React, { useState } from 'react';
import { Search, Filter, Plus, Download, ArrowUpRight, ArrowDownRight, ArrowRightLeft, MoreHorizontal, Calendar, RefreshCw, Trash2, MonitorPlay, Plane, TrendingUp, Paperclip, Flag } from 'lucide-react';
import { useFinance, Transaction } from '../context/FinanceContext';
import { cn } from '../lib/utils';
import { TransactionModal } from '../components/TransactionModal';
import { RecurringTransactionModal } from '../components/RecurringTransactionModal';
import { format, parseISO } from 'date-fns';
import * as Icons from 'lucide-react';

export function Transactions() {
  const { transactions, categories, accounts, recurringTransactions, deleteRecurringTransaction, getCategoryName, formatAmount, flags } = useFinance();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRecurringModalOpen, setIsRecurringModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'INCOME' | 'EXPENSE' | 'TRANSFER'>('ALL');
  const [activeTab, setActiveTab] = useState<'TRANSACTIONS' | 'RECURRING'>('TRANSACTIONS');

  // Filter Transactions
  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          tx.amount.toString().includes(searchTerm);
    const matchesType = filterType === 'ALL' || tx.type === filterType;
    return matchesSearch && matchesType;
  });

  const getAccountName = (id: string) => accounts.find(a => a.id === id)?.name || 'Unknown Account';

  const renderIcon = (iconName: string, size: number) => {
    const Icon = (Icons as any)[iconName] || Flag;
    return <Icon size={size} />;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Transactions</h1>
          <p className="text-slate-500 dark:text-slate-400">Manage your income, expenses, and recurring payments.</p>
        </div>
        <div className="flex gap-2">
          <button className="p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 transition-colors">
            <Download size={20} />
          </button>
          {activeTab === 'TRANSACTIONS' ? (
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-200 dark:shadow-none"
            >
              <Plus size={20} />
              Add Transaction
            </button>
          ) : (
            <button 
              onClick={() => setIsRecurringModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-200 dark:shadow-none"
            >
              <Plus size={20} />
              Add Recurring
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-700">
        <button
          onClick={() => setActiveTab('TRANSACTIONS')}
          className={cn(
            "px-6 py-3 text-sm font-medium border-b-2 transition-colors",
            activeTab === 'TRANSACTIONS' 
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400" 
              : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          )}
        >
          All Transactions
        </button>
        <button
          onClick={() => setActiveTab('RECURRING')}
          className={cn(
            "px-6 py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2",
            activeTab === 'RECURRING' 
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400" 
              : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          )}
        >
          <RefreshCw size={16} />
          Recurring Rules
        </button>
      </div>

      {activeTab === 'TRANSACTIONS' && (
        <>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text" 
                placeholder="Search transactions..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900 dark:text-white placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
              {(['ALL', 'INCOME', 'EXPENSE', 'TRANSFER'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setFilterType(type)}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors",
                    filterType === type 
                      ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900" 
                      : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                  )}
                >
                  {type.charAt(0) + type.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg font-medium hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
              <Filter size={18} />
              Filters
            </button>
          </div>

          {/* Transactions Table */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-700">
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Transaction</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Account</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Amount</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-500 dark:text-slate-400">
                        No transactions found.
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "w-10 h-10 rounded-full flex items-center justify-center",
                              tx.type === 'INCOME' ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400" :
                              tx.type === 'EXPENSE' ? "bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400" :
                              "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                            )}>
                              {tx.type === 'INCOME' ? <ArrowDownRight size={18} /> :
                               tx.type === 'EXPENSE' ? <ArrowUpRight size={18} /> :
                               <ArrowRightLeft size={18} />}
                            </div>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-white">{tx.description}</p>
                              <div className="flex gap-1 mt-1 flex-wrap">
                                {tx.flagIds && tx.flagIds.map(flagId => {
                                  const flag = flags.find(f => f.id === flagId);
                                  if (!flag) return null;
                                  return (
                                    <span key={flagId} className={cn(
                                      "text-[10px] px-1.5 py-0.5 rounded-full flex items-center gap-0.5",
                                      `bg-${flag.color}-100 dark:bg-${flag.color}-900/30 text-${flag.color}-700 dark:text-${flag.color}-300`
                                    )}>
                                      {renderIcon(flag.icon, 8)} {flag.name}
                                    </span>
                                  );
                                })}
                                {tx.attachments && tx.attachments.length > 0 && <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full flex items-center gap-0.5"><Paperclip size={8} /> File</span>}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1">
                            {tx.categoryIds.map(catId => (
                              <span key={catId} className="px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs rounded-lg">
                                {getCategoryName(catId)}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-300">
                          {getAccountName(tx.sourceAccountId)}
                          {tx.type === 'TRANSFER' && (
                            <span className="text-slate-400 mx-1">→</span>
                          )}
                          {tx.type === 'TRANSFER' && tx.destinationAccountId && getAccountName(tx.destinationAccountId)}
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-300">
                          {tx.date}
                        </td>
                        <td className={cn(
                          "px-6 py-4 text-sm font-bold font-mono text-right",
                          tx.type === 'INCOME' ? "text-emerald-600 dark:text-emerald-400" : "text-slate-900 dark:text-white"
                        )}>
                          {tx.type === 'INCOME' ? '+' : ''}
                          {formatAmount(tx.amount)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                            <MoreHorizontal size={18} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeTab === 'RECURRING' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recurringTransactions.length === 0 ? (
            <div className="col-span-full text-center py-12 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 border-dashed">
              <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-500 dark:text-indigo-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw size={32} />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">No Recurring Rules</h3>
              <p className="text-slate-500 dark:text-slate-400 mb-6">Set up automatic payments for rent, subscriptions, or salary.</p>
              <button 
                onClick={() => setIsRecurringModalOpen(true)}
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors"
              >
                Create First Rule
              </button>
            </div>
          ) : (
            recurringTransactions.map((rule) => (
              <div key={rule.id} className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow relative group">
                <div className="flex justify-between items-start mb-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center",
                    rule.type === 'INCOME' ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400" : "bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400"
                  )}>
                    <RefreshCw size={24} />
                  </div>
                  <div className="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold rounded-full uppercase tracking-wide">
                    {rule.frequency}
                  </div>
                </div>
                
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{rule.description}</h3>
                <p className="text-2xl font-mono font-bold text-slate-900 dark:text-white mb-4">
                  {formatAmount(rule.amount)}
                </p>

                <div className="space-y-2 text-sm text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-700 pt-4">
                  <div className="flex justify-between">
                    <span>Next Due:</span>
                    <span className="font-medium text-slate-900 dark:text-white flex items-center gap-1">
                      <Calendar size={14} />
                      {format(parseISO(rule.nextDueDate), 'MMM d, yyyy')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Account:</span>
                    <span className="font-medium text-slate-900 dark:text-white">{getAccountName(rule.sourceAccountId)}</span>
                  </div>
                </div>

                <button 
                  onClick={() => deleteRecurringTransaction(rule.id)}
                  className="absolute top-4 right-4 text-slate-300 dark:text-slate-600 hover:text-rose-500 dark:hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-all p-2 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg"
                  title="Delete Rule"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))
          )}
        </div>
      )}

      <TransactionModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      <RecurringTransactionModal isOpen={isRecurringModalOpen} onClose={() => setIsRecurringModalOpen(false)} />
    </div>
  );
}
