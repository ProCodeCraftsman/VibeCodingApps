import React, { useState } from 'react';
import { Plus, CreditCard, Wallet, Building2, ArrowRightLeft, Landmark, Banknote, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';
import { useFinance, AccountType, Account } from '../context/FinanceContext';
import { cn } from '../lib/utils';

export function Accounts() {
  const { accounts, getNetWorth, getAssetsTotal, getLiabilitiesTotal, addTransaction, formatAmount } = useFinance();
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);

  const assets = accounts.filter(a => ['BANK', 'LOAN_RECEIVABLE', 'WALLET'].includes(a.type));
  const liabilities = accounts.filter(a => ['CREDIT_CARD', 'LOAN_PAYABLE'].includes(a.type));

  const getIcon = (type: AccountType) => {
    switch (type) {
      case 'BANK': return Building2;
      case 'CREDIT_CARD': return CreditCard;
      case 'LOAN_PAYABLE': return Landmark;
      case 'LOAN_RECEIVABLE': return Banknote;
      default: return Wallet;
    }
  };

  const getAccountTypeLabel = (type: AccountType) => {
    switch (type) {
      case 'BANK': return 'Bank Account';
      case 'CREDIT_CARD': return 'Credit Card';
      case 'LOAN_PAYABLE': return 'Loan (Payable)';
      case 'LOAN_RECEIVABLE': return 'Lending (Receivable)';
      default: return 'Wallet';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header & Net Worth */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Accounts</h1>
          <p className="text-slate-500 dark:text-slate-400">Manage your assets, liabilities, and transfers.</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setIsTransferModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 shadow-sm"
          >
            <ArrowRightLeft size={16} />
            Transfer Funds
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm">
            <Plus size={16} />
            Add Account
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mb-1">Net Worth</p>
          <p className="text-3xl font-bold text-slate-900 dark:text-white font-mono">
            {formatAmount(getNetWorth())}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <ArrowUpCircle size={16} className="text-emerald-500" />
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Total Assets</p>
          </div>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">
            {formatAmount(getAssetsTotal())}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <div className="flex items-center gap-2 mb-1">
            <ArrowDownCircle size={16} className="text-rose-500" />
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Total Liabilities</p>
          </div>
          <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 font-mono">
            {formatAmount(getLiabilitiesTotal())}
          </p>
        </div>
      </div>

      {/* Assets Section */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <span className="w-2 h-6 bg-emerald-500 rounded-full"></span>
          Assets
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {assets.map((account) => (
            <AccountCard key={account.id} account={account} getIcon={getIcon} getLabel={getAccountTypeLabel} formatAmount={formatAmount} />
          ))}
        </div>
      </div>

      {/* Liabilities Section */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <span className="w-2 h-6 bg-rose-500 rounded-full"></span>
          Liabilities
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {liabilities.map((account) => (
            <AccountCard key={account.id} account={account} getIcon={getIcon} getLabel={getAccountTypeLabel} formatAmount={formatAmount} />
          ))}
        </div>
      </div>

      {/* Transfer Modal */}
      {isTransferModalOpen && (
        <TransferModal 
          isOpen={isTransferModalOpen} 
          onClose={() => setIsTransferModalOpen(false)} 
          accounts={accounts}
          onTransfer={(data) => {
            addTransaction({
              date: new Date().toISOString().split('T')[0],
              description: 'Transfer',
              type: 'TRANSFER',
              amount: Number(data.amount),
              sourceAccountId: data.sourceId,
              destinationAccountId: data.destinationId,
              categoryIds: [],
              flagIds: []
            });
            setIsTransferModalOpen(false);
          }}
        />
      )}
    </div>
  );
}

const AccountCard: React.FC<{ account: Account, getIcon: (type: AccountType) => React.ElementType, getLabel: (type: AccountType) => string, formatAmount: (amount: number) => string }> = ({ account, getIcon, getLabel, formatAmount }) => {
  const Icon = getIcon(account.type);
  const isLiability = ['CREDIT_CARD', 'LOAN_PAYABLE'].includes(account.type);
  
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden group hover:shadow-md transition-shadow">
      <div className={cn("h-24 p-6 relative", account.color)}>
        <div className="absolute top-4 right-4 text-white/80">
          <Icon size={24} />
        </div>
        <div className="absolute bottom-4 left-6 text-white">
          <p className="text-xs opacity-80 uppercase tracking-wider">{getLabel(account.type)}</p>
          <p className="font-medium truncate pr-8">{account.bankName}</p>
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-end mb-4">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">{account.name}</p>
            <p className={cn("text-2xl font-bold font-mono", isLiability ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400")}>
              {formatAmount(account.balance)}
            </p>
          </div>
        </div>
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700">
          <p className="text-sm text-slate-500 dark:text-slate-400 font-mono">{account.accountNumber || '****'}</p>
          <button className="text-sm text-indigo-600 dark:text-indigo-400 font-medium hover:text-indigo-700">Details</button>
        </div>
      </div>
    </div>
  );
}

function TransferModal({ isOpen, onClose, accounts, onTransfer }: { isOpen: boolean, onClose: () => void, accounts: Account[], onTransfer: (data: any) => void }) {
  const { settings } = useFinance();
  const [sourceId, setSourceId] = useState(accounts[0]?.id || '');
  const [destinationId, setDestinationId] = useState(accounts[1]?.id || '');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceId || !destinationId || !amount) return;
    onTransfer({ sourceId, destinationId, amount });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Transfer Funds</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <span className="sr-only">Close</span>
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">From Account</label>
            <select 
              value={sourceId} 
              onChange={(e) => setSourceId(e.target.value)}
              className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900 dark:text-white"
            >
              {accounts.map(acc => (
                <option key={acc.id} value={acc.id}>{acc.name} ({acc.type}) - ${acc.balance}</option>
              ))}
            </select>
          </div>
          
          <div className="flex justify-center">
            <div className="bg-slate-100 dark:bg-slate-700 p-2 rounded-full text-slate-500 dark:text-slate-400">
              <ArrowDownCircle size={24} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">To Account</label>
            <select 
              value={destinationId} 
              onChange={(e) => setDestinationId(e.target.value)}
              className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900 dark:text-white"
            >
              {accounts.map(acc => (
                <option key={acc.id} value={acc.id} disabled={acc.id === sourceId}>
                  {acc.name} ({acc.type}) - ${acc.balance}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Amount</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-400 font-bold">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: settings.currency }).format(0).replace(/\d/g, '').replace(/[.,]/g, '').trim()}
              </span>
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-bold text-lg text-slate-900 dark:text-white"
                placeholder="0.00"
                min="0.01"
                step="0.01"
              />
            </div>
          </div>

          <div className="pt-4">
            <button 
              type="submit"
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 dark:shadow-none"
            >
              Confirm Transfer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
